﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tweede : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int korting = 0;

        if (Application["SMAC37088"] != null)
        {
            korting += 10;
        }
        if (Application["MACS99041"] != null)
        {
            korting += 10;
        }

        lbl_Korting.Text = "U krijgt maar liefst " + korting + " procent korting!";
    }
}