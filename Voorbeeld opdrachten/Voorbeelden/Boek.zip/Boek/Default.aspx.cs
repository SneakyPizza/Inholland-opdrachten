﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    const int VERLOOP = 30;
    const double PRIJS = 14.50;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lbl_Prijs.Text = PRIJS.ToString("C");
        }
    }
    protected void btn_Bestellen_Click(object sender, EventArgs e)
    {
        int aantal = 0;
        
        if (Request.Cookies["Mandje"] != null)
        {
            aantal = int.Parse(Request.Cookies["Mandje"]["Aantal"]);
        }

        aantal++;

        Response.Cookies["Mandje"]["Aantal"] = aantal.ToString();
        Response.Cookies["Mandje"].Expires = DateTime.Now.AddDays(VERLOOP);
    }
    protected void btn_Test_Click(object sender, EventArgs e)
    {
        int aantal = int.Parse(Request.Cookies["Mandje"]["Aantal"]);

        lbl_Test.Text = "Het aantal boeken in uw mandje: " + aantal;
    }
    protected void btn_Bijwerken_Click(object sender, EventArgs e)
    {
        string code = txt_Actiecode.Text;
        Application[code] = 1;
    }
}